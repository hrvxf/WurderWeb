# @wurder/shared-analytics

Canonical shared analytics contract package for Wurder.

## Purpose

This package is the single source of truth for:

- analytics response types used across backend/app/web
- null-safe analytics math helpers
- session and participant semantics used by analytics/reporting flows

The package is intentionally framework-agnostic and platform-neutral.

## Public Exports

From `@wurder/shared-analytics`:

- Types:
  - `DashboardResponse`
  - `PlayerPerformance`
  - `Overview`
  - `Insights`
  - `SessionSummary`
  - `EventTotals`
  - `SessionStatus`
  - `ParticipantRole`
  - `ParticipantRecord`
- Constants:
  - `BASELINE_POINTS_PER_CONFIRMED_KILL`
- Helpers:
  - `safeDivide`
  - `mean`
  - `computeKd`
  - `computeAccuracy`
  - `computeDisputeRate`
  - `computeEfficiency`
  - `deriveSessionStatus`
  - `computeDurationMs`
  - plus supporting pure helpers exported by `src/index.ts`

## Out Of Scope

Do **not** add the following to this package:

- Firebase SDK/admin code
- Firestore reads/writes
- HTTP/API handlers
- auth/access control decisions
- React/Expo/Next.js UI code
- gameplay mutation logic

Keep this package focused on pure analytics contract types + pure deterministic helpers.

## Build

```bash
npm run build
```

Build artifacts are emitted to `dist/` and exposed through package exports.
